# FinanzTracker Pro – Cloudflare Worker

Struktur für Cloudflare Workers + Static Assets.

- `_worker.js` = serverseitige API-Routen für Stripe/Webhooks
- `public/` = Website-Dateien
- `wrangler.jsonc` = Worker + Static Assets Konfiguration

In Cloudflare Git Builds:
- Build command: leer
- Deploy command: `npx wrangler deploy`
- Version command: leer
- Root directory: leer

Runtime Secrets später ausschließlich in Cloudflare hinterlegen:
- STRIPE_SECRET_KEY
- STRIPE_PRICE_PRO
- STRIPE_WEBHOOK_SECRET
- SUPABASE_SECRET_KEY

Öffentliche Website-Konfiguration liegt in `public/config.js`.
